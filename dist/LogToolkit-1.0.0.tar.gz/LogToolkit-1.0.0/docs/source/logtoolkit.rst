logtoolkit package
==================

Module contents
---------------

.. automodule:: logtoolkit
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

logtoolkit.models module
------------------------

.. automodule:: logtoolkit.models
   :members:
   :undoc-members:
   :show-inheritance:

logtoolkit.types module
-----------------------

.. automodule:: logtoolkit.types
   :members:
   :undoc-members:
   :show-inheritance:

   .. autodata:: FormatStyle
   .. autodata:: LogLevel
   .. autodata:: FormattersModels
   .. autodata:: StreamHandlersModels
   .. autodata:: FileHandlersModels
   .. autodata:: ColorName

