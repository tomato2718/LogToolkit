# Change Log
## 1.0.2 (2023/08/23)
### Bug fixes
- **Docs:** Fix typo in docstring of `quickConfig`. [@tomato2718]

## 1.0.1 (2023/08/23)
### Features and enhancements
- **Refactor:** Improve code performance. [@tomato2718]

## 1.0.0 (2023/07/30)
### Features and enhancements
- **Feat:** Create main module. [@tomato2718]
- **Docs:** Create documents. [@tomato2718]
- **Tests:** Create unit tests. [@tomato2718]
- **Chore:** Update project information. [@tomato2718]

## 0.0.0 (1900/01/01)
### Features and enhancements

### Bug fixes



<!-- Links -->
[@tomato2718]: yveschen2718@gmail.com